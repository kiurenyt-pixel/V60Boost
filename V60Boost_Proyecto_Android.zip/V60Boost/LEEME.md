# V60 Boost — HaniGMY (0.1)
Proyecto nativo Android, compatible desde Android 10. Primera versión sin root.

## Generar el APK
1. En un PC instala Android Studio y abre esta carpeta como proyecto.
2. Usa JDK 17, Android SDK 35 y Gradle 8.9 (Android Studio puede instalar las dependencias; requiere Internet).
3. Si solicita el wrapper, configura Gradle local 8.9 o ejecuta `gradle wrapper --gradle-version 8.9` con Gradle instalado.
4. Sincroniza y usa Build > Build App Bundle(s) / APK(s) > Build APK(s).
5. El APK de depuración queda en app/build/outputs/apk/debug/app-debug.apk. Cópialo al LG V60 e instálalo autorizando esa fuente.

## Funciones reales
- Ultra/Alto/Medio/Bajo ajustan exclusivamente brillo y apagado de pantalla, con confirmación que enumera los cambios. No son modos de CPU.
- Android pide además permiso de modificar ajustes. Tras concederlo debes elegir otra vez el perfil.
- Guarda los valores originales antes del primer perfil y permite restaurarlos con confirmación. Restaurar antes de desinstalar: desinstalar no revierte ajustes del sistema.
- Lecturas reales de batería, temperatura de batería y RAM disponible cada 5 segundos, solo mientras la app es visible.
- Selector de juegos y accesos confirmados a No molestar, batería, Wi-Fi, pantalla y almacenamiento.
- Carga ultra rápida se presenta como no activable, con explicación. No modifica hardware ni protecciones.
- No usa red, root, accesibilidad, servicios residentes ni limpieza de RAM ficticia.

## Validación pendiente
No se ha compilado el APK ni probado en un LG V60: el entorno de entrega no tiene Android SDK/Gradle. Es código fuente, no un APK listo para instalar. La mejora de FPS no está medida ni garantizada.

## Prueba en dispositivo
1. Cancela cada diálogo y comprueba que ningún ajuste cambia.
2. Sin permiso, acepta un perfil: solo debe ofrecer la pantalla de permiso. Concederlo y volver no aplica nada.
3. Aplica un perfil y verifica brillo manual/tiempo de apagado; restaura y compara con los originales.
4. Cierra y abre la app: no debe aplicar ajustes. El estado mostrado es el último resultado, no monitoriza cambios externos.
5. Abre un juego: pide confirmación y no cambia ajustes de sistema.
6. Comprueba las pantallas de ajustes disponibles en tu firmware y los datos de batería.

Ante cambio parcial por firmware/permisos se avisa y se mantiene la copia original para restaurar. Guarda tus ajustes manualmente si vas a borrar los datos de la app.
