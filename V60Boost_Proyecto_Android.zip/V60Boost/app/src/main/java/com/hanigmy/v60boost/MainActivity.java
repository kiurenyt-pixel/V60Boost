package com.hanigmy.v60boost;

import android.app.*;
import android.os.*;
import android.content.*;
import android.content.pm.*;
import android.provider.Settings;
import android.net.Uri;
import android.graphics.Color;
import android.widget.*;
import android.view.*;
import java.util.*;

public class MainActivity extends Activity {
 private LinearLayout body; private TextView stats, state;
 private final Handler handler = new Handler(Looper.getMainLooper());
 private final Runnable refresh = new Runnable(){ public void run(){ updateStats(); handler.postDelayed(this,5000); }};
 private SharedPreferences prefs;
 private int ink=Color.rgb(227,239,255), accent=Color.rgb(80,200,240);
 public void onCreate(Bundle b){super.onCreate(b);prefs=getSharedPreferences("baseline",0);
  getWindow().setStatusBarColor(Color.rgb(12,19,33));getWindow().setNavigationBarColor(Color.rgb(12,19,33));
  ScrollView scroll=new ScrollView(this); body=new LinearLayout(this);body.setOrientation(1);body.setPadding(30,50,30,40);body.setBackgroundColor(Color.rgb(12,19,33));scroll.addView(body);setContentView(scroll);
  label("HaniGMY / ANDROID",14,accent);label("V60 Boost",32,ink);
  label("Control de ajustes · Sin root · Confirmación por acción",14,ink);
  stats=label("Leyendo sensores…",17,accent);state=label("Perfil: ninguno aplicado",16,ink);
  label("PERFILES",19,accent);
  label("Son presets de pantalla, no overclock. No cambian CPU, GPU, RAM ni los FPS de tus juegos.",14,ink);
  button("Ultra · brillo 85% / 10 minutos",()->profile("Ultra",217,600000));
  button("Alto · brillo 70% / 5 minutos",()->profile("Alto",179,300000));
  button("Medio · brillo 50% / 2 minutos",()->profile("Medio",128,120000));
  button("Bajo · brillo 25% / 30 segundos",()->profile("Bajo",64,30000));
  button("Restaurar ajustes anteriores",()->confirm("Restaurar", "Se restaurarán el brillo, su modo automático/manual y el tiempo de apagado guardados antes del primer perfil.",this::restore));
  label("GAMING",19,accent);
  label("Prepara la sesión manualmente. No cierra otras apps ni cambia ajustes al abrir un juego.",14,ink);
  button("Elegir juego / aplicación",()->confirm("Abrir selector", "Se leerán las aplicaciones con icono de inicio. Seleccionar una pedirá otra confirmación antes de abrirla.",this::apps));
  shortcut("No molestar",Settings.ACTION_ZEN_MODE_SETTINGS,"Abre Android para que elijas si silenciar las interrupciones.");
  shortcut("Ahorro de batería",Settings.ACTION_BATTERY_SAVER_SETTINGS,"Abre Android. Puedes revisar si el ahorro de batería limita tu sesión de juego.");
  shortcut("Pantalla / resolución",Settings.ACTION_DISPLAY_SETTINGS,"Abre ajustes de pantalla. Los controles disponibles dependen del firmware de LG.");
  shortcut("Wi-Fi",Settings.ACTION_WIFI_SETTINGS,"Abre Wi-Fi para elegir tu conexión. La app no modifica la red.");
  label("CARGA Y SISTEMA",19,accent);
  button("Carga ultra rápida · no activable por esta app",()->confirm("Revisar carga", "Esta app no puede aumentar la potencia de carga. La velocidad depende del teléfono, cargador, cable y temperatura. No se modifican corriente, voltaje ni límites térmicos. ¿Abrir los ajustes de batería?",()->open(new Intent(Settings.ACTION_BATTERY_SAVER_SETTINGS))));
  shortcut("Almacenamiento",Settings.ACTION_INTERNAL_STORAGE_SETTINGS,"Abre el almacenamiento. La app no borra archivos ni cachés de otros programas.");
  button("CPU/GPU y limpieza de RAM · límites",()->confirm("Información", "Android no permite a esta app controlar las frecuencias de otras aplicaciones ni garantizar 60 FPS. No incluimos un botón de limpieza con resultados ficticios.",()->{}));
  label("No hay cambios automáticos al iniciar. Cancelar una confirmación no ejecuta la acción. Sin anuncios ni permiso de Internet.",14,ink);
 }
 TextView label(String s,int size,int color){TextView v=new TextView(this);v.setText(s);v.setTextSize(size);v.setTextColor(color);v.setPadding(0,12,0,12);body.addView(v);return v;}
 void button(String title,Runnable r){Button b=new Button(this);b.setText(title);b.setAllCaps(false);b.setTextColor(ink);b.setBackgroundTintList(android.content.res.ColorStateList.valueOf(Color.rgb(28,43,64)));LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-1,-2);p.setMargins(0,8,0,8);body.addView(b,p);b.setOnClickListener(v->r.run());}
 void confirm(String title,String msg,Runnable action){new AlertDialog.Builder(this).setTitle(title).setMessage(msg).setNegativeButton("Cancelar",null).setPositiveButton("Permitir",(d,w)->action.run()).show();}
 void shortcut(String name,String action,String explanation){button(name,()->confirm(name,explanation,()->open(new Intent(action))));}
 void open(Intent i){try{startActivity(i);}catch(Exception e){new AlertDialog.Builder(this).setMessage("Esta pantalla no está disponible en tu firmware.").setPositiveButton("Cerrar",null).show();}}
 boolean permission(){if(Settings.System.canWrite(this))return true;confirm("Permiso de Android", "Debes autorizar modificar ajustes del sistema. Después vuelve y selecciona el perfil de nuevo; no se aplicará automáticamente.",()->open(new Intent(Settings.ACTION_MANAGE_WRITE_SETTINGS,Uri.parse("package:"+getPackageName()))));return false;}
 int read(String key,int fallback){return Settings.System.getInt(getContentResolver(),key,fallback);}
 boolean put(String key,int value){return Settings.System.putInt(getContentResolver(),key,value);}
 void profile(String name,int brightness,int timeout){confirm("Aplicar "+name,"Cambiará el brillo a "+Math.round(brightness*100f/255)+"%, desactivará el brillo automático y fijará el apagado en "+timeout/1000+" segundos. Puede afectar consumo y comodidad. No cambia CPU/GPU. ¿Permitir estos tres cambios?",()->{if(!permission())return;
  if(!prefs.contains("brightness"))prefs.edit().putInt("brightness",read(Settings.System.SCREEN_BRIGHTNESS,128)).putInt("mode",read(Settings.System.SCREEN_BRIGHTNESS_MODE,1)).putInt("timeout",read(Settings.System.SCREEN_OFF_TIMEOUT,60000)).commit();
  write(brightness,0,timeout,"Perfil: "+name+" · ajustes de pantalla aplicados");});}
 void write(int brightness,int mode,int timeout,String success){try{boolean a=put(Settings.System.SCREEN_BRIGHTNESS,brightness);boolean b=put(Settings.System.SCREEN_BRIGHTNESS_MODE,mode);boolean c=put(Settings.System.SCREEN_OFF_TIMEOUT,timeout);if(a&&b&&c){state.setText(success);prefs.edit().putString("status",success).apply();}else{state.setText("Cambio parcial: restaura los ajustes anteriores");prefs.edit().putString("status",state.getText().toString()).apply();}}catch(Exception e){state.setText("No se completó: revisa permisos y restaura los ajustes");prefs.edit().putString("status",state.getText().toString()).apply();}}
 void restore(){if(!prefs.contains("brightness")){Toast.makeText(this,"No hay ajustes guardados",0).show();return;}if(!permission())return;write(prefs.getInt("brightness",128),prefs.getInt("mode",1),prefs.getInt("timeout",60000),"Ajustes anteriores restaurados");if(state.getText().toString().equals("Ajustes anteriores restaurados"))prefs.edit().clear().apply();}
 void apps(){Intent query=new Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER);List<ResolveInfo> list=getPackageManager().queryIntentActivities(query,0);Collections.sort(list,(a,b)->a.loadLabel(getPackageManager()).toString().compareToIgnoreCase(b.loadLabel(getPackageManager()).toString()));String[] labels=new String[list.size()];for(int i=0;i<list.size();i++)labels[i]=list.get(i).loadLabel(getPackageManager()).toString();new AlertDialog.Builder(this).setTitle("Selecciona tu juego").setItems(labels,(d,n)->{ResolveInfo info=list.get(n);confirm("Abrir "+labels[n],"Se abrirá esta aplicación sin aplicar perfiles ni otros cambios.",()->open(new Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER).setComponent(new ComponentName(info.activityInfo.packageName,info.activityInfo.name))));}).setNegativeButton("Cancelar",null).show();}
 void updateStats(){Intent b=registerReceiver(null,new IntentFilter(Intent.ACTION_BATTERY_CHANGED));ActivityManager.MemoryInfo m=new ActivityManager.MemoryInfo();((ActivityManager)getSystemService(ACTIVITY_SERVICE)).getMemoryInfo(m);String battery="Sin lectura";if(b!=null){int level=b.getIntExtra(BatteryManager.EXTRA_LEVEL,-1),scale=b.getIntExtra(BatteryManager.EXTRA_SCALE,-1),temp=b.getIntExtra(BatteryManager.EXTRA_TEMPERATURE,Integer.MIN_VALUE);battery=(level>=0&&scale>0?Math.round(level*100f/scale)+"%":"N/D")+" · Batería "+(temp!=Integer.MIN_VALUE?String.format(Locale.US,"%.1f °C",temp/10f):"N/D");}stats.setText(Build.MODEL+" · Android "+Build.VERSION.RELEASE+"\n"+battery+"\nRAM disponible: "+String.format(Locale.US,"%.1f GB",m.availMem/1073741824f)+"\nTemperatura de batería; no es la de CPU/GPU.");}
 protected void onResume(){super.onResume();state.setText(prefs.getString("status","Perfil: ninguno aplicado"));handler.post(refresh);}
 protected void onPause(){handler.removeCallbacks(refresh);super.onPause();}
}
